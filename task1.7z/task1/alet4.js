//function min(a, b) {
 //   if (a < b) {
 //     return a;
 //   } else if (a > b){
 //     return b;
 //   } else {
 //       return b;
 //   }
 // }
//let result = min(1,2);
//alert(result);

//function pow(x,n) {
//    return (x ** n);
//  }
//let result = pow(2,4);
//alert(result);

var chisl = 12;
alert('Перевод в 8-ичную: ' + chisl.toString(8));
alert('Перевод в 2-ичную: ' + chisl.toString(2)); 