function nod(chisl){
for(let del1 = 2; del1 <= chisl;){
if (chisl % del1 == 0){
    chisl = chisl / del1;
    document.write(del1 + '<br>');
}
else{
    del1++;
}
}
}
    nod(775)