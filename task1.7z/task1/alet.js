let i = 4;
//for(; i % 2 == 0;){
//alert (i);}

while (i % 2 == 0){
  alert(i);
}  