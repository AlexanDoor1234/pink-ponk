//for (i = 5; i >= 1; i--) {
//	document.write(i + '<br>');
//}

//for ( let i = 11; i <= 33; i++) {
//	document.write(i + '<br>');
//}

//for (i = 0; i <= 100; i++) {
//    if (i % 2 == 0){
//	document.write(i + '<br>');
//    }
//}

//let i2 = 0;
//for (i = 100; i > 0; i--) {
//i2 = i2 + i;
//}
//alert (i2);

//for (let i = 2; i <= 10; i++) {
//    if (i % 2 == 0) {
//      alert( i );
//    }
//  }